﻿using System.Reflection;
using System.Runtime.InteropServices;

// Assembly-specific attributes

[assembly: AssemblyTitle("FasterflectSample")]
[assembly: Guid("4b8adab7-4b50-439e-95a2-411144626bc2")]
