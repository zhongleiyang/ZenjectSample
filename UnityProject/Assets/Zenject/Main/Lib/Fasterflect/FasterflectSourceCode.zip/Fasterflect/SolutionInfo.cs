﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Solution-wise assembly attributes (linked into each project)

[assembly: AssemblyDescription("Fast & Simple .NET Reflection Library")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Buu Nguyen & Morten Mertner")]
[assembly: AssemblyProduct("Fasterflect")]
[assembly: AssemblyCopyright("Copyright © Buu Nguyen & Morten Mertner 2010-2013")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: CLSCompliant(true)]
[assembly: ComVisible(false)]

[assembly: AssemblyVersion("2.1.3")]
[assembly: AssemblyFileVersion("2.1.3")]
