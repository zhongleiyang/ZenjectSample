﻿using System.Reflection;
using System.Runtime.InteropServices;

// Assembly-specific attributes

[assembly: AssemblyTitle("FasterflectTest")]
[assembly: Guid("d1265d93-1e64-4a27-8660-f0106d4620a5")]
