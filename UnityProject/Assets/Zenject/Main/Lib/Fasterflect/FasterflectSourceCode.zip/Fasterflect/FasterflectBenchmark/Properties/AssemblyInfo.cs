﻿using System.Reflection;
using System.Runtime.InteropServices;

// Assembly-specific attributes

[assembly: AssemblyTitle("FasterflectBenchmark")]
[assembly: Guid("562d8b60-7f32-41ad-8455-d747b5455a2b")]
